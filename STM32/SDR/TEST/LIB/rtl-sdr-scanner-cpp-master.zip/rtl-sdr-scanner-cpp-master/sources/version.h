constexpr auto GIT_COMMIT = "";
constexpr auto GIT_TAG = "";
