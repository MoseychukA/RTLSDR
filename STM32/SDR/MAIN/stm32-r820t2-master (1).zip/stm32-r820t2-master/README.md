# stm32-r820t2

STM32: example of usage of R820T2 tuner.

Based on IceRadio project by Eric Brombaugh ([@emeb][u1]). The code was ported to HAL
and refactored a little bit.

See also:

* https://github.com/emeb/iceRadio
* https://github.com/emeb/r820t2/
* http://ebrombaugh.studionebula.com/radio/iceRadio/index.html

[u1]: https://github.com/emeb
